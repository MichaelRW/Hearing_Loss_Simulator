API
===

.. automodule:: hearinglosssimulator